import React, { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import App from './App';
import LoginPage from './components/auth/LoginPage';
import OrderBook from './components/orderbook/OrderBook';
import PositionsPanel from './components/positions/PositionsPanel';
import UserSettings from './components/user/UserSettings';
import StrategiesComponent from './components/strategies/StrategiesComponent';
import MultiLegComponent from './components/multileg/MultiLegComponent';

const ProtectedRoute = ({ children }) => {
  const isAuthenticated = localStorage.getItem('isAuthenticated') === 'true';
  
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }
  
  return children;
};

const AppRouter = () => {
  // Check if user is coming from login page
  useEffect(() => {
    const path = window.location.pathname;
    if (path === '/' || path === '') {
      const isAuthenticated = localStorage.getItem('isAuthenticated') === 'true';
      if (!isAuthenticated) {
        // Redirect to login if not authenticated
        window.history.replaceState(null, '', '/login');
      }
    }
  }, []);

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<LoginPage />} />
        <Route path="/" element={
          <ProtectedRoute>
            <App />
          </ProtectedRoute>
        }>
          <Route index element={<Navigate to="/orderbook" replace />} />
          <Route path="orderbook" element={<OrderBook />} />
          <Route path="positions" element={<PositionsPanel />} />
          <Route path="user-settings" element={<UserSettings />} />
          <Route path="strategies" element={<StrategiesComponent />} />
          <Route path="multi-leg" element={<MultiLegComponent />} />
        </Route>
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
};

export default AppRouter;
