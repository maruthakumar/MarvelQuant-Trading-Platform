import React, { useState } from 'react';
import { 
  Box, 
  Typography, 
  Paper, 
  Divider,
  IconButton,
  List,
  ListItem,
  ListItemText
} from '@mui/material';
import RefreshIcon from '@mui/icons-material/Refresh';

const LogsPanel = () => {
  const [logs, setLogs] = useState([
    { timestamp: '09:15:00', level: 'INFO', message: 'Application initialized' },
    { timestamp: '09:15:01', level: 'INFO', message: 'Connected to market data feed' },
    { timestamp: '09:15:02', level: 'INFO', message: 'User Admin logged in' },
    { timestamp: '09:15:30', level: 'INFO', message: 'Range calculation started for NIFTY' },
    { timestamp: '09:16:00', level: 'WARNING', message: 'Market data feed experiencing delays' },
    { timestamp: '09:16:30', level: 'INFO', message: 'Range High: 22550, Range Low: 22450' },
    { timestamp: '09:31:15', level: 'INFO', message: 'Breakout detected: NIFTY above 22550' },
    { timestamp: '09:31:16', level: 'INFO', message: 'BUY order placed: 75 NIFTY @ 22555 (LIMIT)' },
    { timestamp: '09:31:45', level: 'INFO', message: 'Order filled: 75 NIFTY @ 22555' },
    { timestamp: '09:35:20', level: 'INFO', message: 'Trailing stoploss updated: 22530' },
    { timestamp: '09:40:15', level: 'INFO', message: 'Trailing stoploss updated: 22540' },
    { timestamp: '09:45:30', level: 'SUCCESS', message: 'Target hit: SELL 75 NIFTY @ 22655' },
    { timestamp: '09:45:31', level: 'SUCCESS', message: 'P&L: +₹7,500 (+0.44%)' }
  ]);
  
  const [logFilter, setLogFilter] = useState('ALL');
  
  const getLogColor = (level) => {
    switch(level) {
      case 'ERROR':
        return 'error.main';
      case 'WARNING':
        return 'warning.main';
      case 'SUCCESS':
        return 'success.main';
      case 'INFO':
      default:
        return 'text.primary';
    }
  };
  
  const handleRefreshLogs = () => {
    // In a real implementation, this would fetch the latest logs from the backend
    console.log('Refreshing logs');
    // For demo purposes, add a new log entry
    const newLog = {
      timestamp: new Date().toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      level: 'INFO',
      message: 'Logs refreshed'
    };
    setLogs([...logs, newLog]);
  };
  
  const filteredLogs = logFilter === 'ALL' 
    ? logs 
    : logs.filter(log => log.level === logFilter);
  
  return (
    <Paper sx={{ p: 2 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}>
        <Typography variant="subtitle1">System Logs</Typography>
        <IconButton size="small" onClick={handleRefreshLogs} title="Refresh logs">
          <RefreshIcon />
        </IconButton>
      </Box>
      <Divider sx={{ mb: 1 }} />
      
      <Box sx={{ height: '150px', overflow: 'auto' }}>
        {filteredLogs.map((log, index) => (
          <Typography 
            key={index} 
            variant="body2" 
            sx={{ 
              mb: 0.5, 
              color: getLogColor(log.level),
              fontFamily: 'monospace'
            }}
          >
            [{log.timestamp}] {log.level}: {log.message}
          </Typography>
        ))}
      </Box>
    </Paper>
  );
};

export default LogsPanel;
